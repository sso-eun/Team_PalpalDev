// app/src/main/java/com/example/dundun_hi/MainActivity.kt
package com.example.dundun_hi

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.dundun_hi.model.SharedPhoto
import com.example.dundun_hi.ui.CameraScreen
import com.example.dundun_hi.ui.GuardianScreen
import com.example.dundun_hi.ui.Guardian_SignupScreen
import com.example.dundun_hi.ui.HomeScreen
import com.example.dundun_hi.ui.KioskScreen
import com.example.dundun_hi.ui.ProfileScreen
import com.example.dundun_hi.ui.SetupShortcutScreen
import com.example.dundun_hi.ui.login.LoginScreen
import com.example.dundun_hi.ui.login.LoginViewModel
import com.example.dundun_hi.ui.main.MainScreen
import com.example.dundun_hi.ui.screen.CallScreen
import com.example.dundun_hi.ui.screen.CallViewModel
import com.example.dundun_hi.ui.screen.LastPhotoScreen
import com.example.dundun_hi.ui.signup.SignupResult
import com.example.dundun_hi.ui.signup.SignupScreen
import com.example.dundun_hi.ui.signup.SignupViewModel
import com.example.dundun_hi.ui.theme.DundunHiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // SharedPreferences (로그인 유지용)
        val prefs = getSharedPreferences("login_prefs", Context.MODE_PRIVATE)

        setContent {
            DundunHiTheme {
                Surface(Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(
                        navController    = navController,
                        startDestination = "home"                 // ▶ ① 항상 home
                    ) {
//                        [앱실행 로직]
//                        1. 앱 시작 시 SharedPreferences(또는 DataStore)에 저장된 인증 정보를
//                        2. 한 번만 검사해서
//                        3. 로그인 정보가 남아 있으면 MainScreen으로,
//                        4. 없으면 Home(로그인·회원가입) 화면으로 보내는 구조

                        /* ───── 홈 화면 ───── */
                        composable("home") {
                            // 앱 진입 또는 뒤로 돌아왔을 때 한 번만 검사
                            LaunchedEffect(Unit) {
                                if (!prefs.getString("auth_token", "").isNullOrEmpty()) {
                                    // 로그인 토큰이 남아 있으면 바로 main으로
                                    navController.navigate("main") {
                                        popUpTo("home") { inclusive = true }
                                    }
                                }
                            }

                            HomeScreen(
                                onLoginClick    = { navController.navigate("login") },
                                onSignupClick   = { navController.navigate("signup") },
                                onGuardianClick = { navController.navigate("guardian") }
                            )
                        }

                        /* ── 로그인 화면 ── */
                        composable("login") {
                            val loginVm: LoginViewModel = viewModel(
                                factory = ViewModelProvider
                                    .AndroidViewModelFactory
                                    .getInstance(LocalContext.current.applicationContext as android.app.Application)
                            )
                            LoginScreen(
                                onLoginSuccess = { token ->
                                    prefs.edit()
                                        .putString("auth_token", token)
                                        .apply()
                                    navController.navigate("main") { popUpTo("home") { inclusive = true } }
                                }
                            )
                        }

                        /* ── 회원가입 화면 ── */
                        composable("signup") {
                            val vm: SignupViewModel = viewModel()
                            val state by vm.state.collectAsState()
                            SignupScreen { req -> vm.signup(req) }

                            LaunchedEffect(state) {
                                if (state is SignupResult.Success) {
                                    navController.navigate("main") {
                                        popUpTo("home") { inclusive = true }
                                    }
                                } else if (state is SignupResult.Error) {
                                    Toast.makeText(
                                        this@MainActivity,
                                        (state as SignupResult.Error).reason,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }

                        /* ── 보호자 화면 ── */
                        composable("guardian") {
                            GuardianScreen(
                                onSubmit      = { _, _ -> },
                                onSignupClick = { navController.navigate("guardian_signup") }
                            )
                        }
                        composable("guardian_signup") {
                            Guardian_SignupScreen()
                        }

                        /* ───── 메인 메뉴 ───── */
                        composable("main") {
                            MainScreen(
                                temperature         = 19,
                                highTemp            = 25,
                                lowTemp             = 7,
                                onPhonePageClick    = { navController.navigate("call") },
                                onMessagePageClick  = {},
                                onCameraPageClick   = { navController.navigate("camera") },
                                onMapPageClick      = {},
                                onFindCultureCenter = {},
                                onKioskPageClick    = { navController.navigate("kiosk") },
                                onProfileClick      = { navController.navigate("profile") }
                            )
                        }

                        /* ───── 그 외 화면들 ───── */
                        composable("kiosk")  { KioskScreen() }
                        composable("camera"){ CameraScreen(navController) }
                        composable("lastphoto") {
                            val dummy = listOf(
                                SharedPhoto(R.drawable.img1, true),
                                SharedPhoto(R.drawable.img2, false),
                                SharedPhoto(R.drawable.img3, true)
                            )
                            LastPhotoScreen(photos = dummy, onAddPhoto = {})
                        }
                        composable("profile") { ProfileScreen() }
                        composable("call") {
                            val vm: CallViewModel = viewModel()
                            val shortcuts by vm.shortcuts.collectAsState()
                            CallScreen(
                                contacts      = shortcuts,
                                onAddShortcut = { idx ->
                                    navController.navigate("call_setup/$idx")
                                }
                            )
                        }
                        composable("call_setup/{index}") { back ->
                            val vm: CallViewModel = viewModel()
                            val idx = back.arguments?.getString("index")?.toIntOrNull() ?: 0
                            SetupShortcutScreen(index = idx) {
                                vm.loadShortcuts()
                                navController.popBackStack()
                            }
                        }
                    }
                }
            }
        }
    }
}
