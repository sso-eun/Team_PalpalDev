// app/src/main/java/com/example/dundun_hi/ui/login/LoginViewModel.kt
package com.example.dundun_hi.ui.login

import android.app.Application
import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dundun_hi.data.LoginRequest
import com.example.dundun_hi.data.LoginResponse
import com.example.dundun_hi.network.RetrofitClient
import kotlinx.coroutines.launch

class LoginViewModel(
    application: Application                         // ▶ 생성자에 Application 추가
) : AndroidViewModel(application) {                 // ▶ AndroidViewModel 상속

    private val prefs = application                   // ▶ getApplication() 대신 바로 application 사용
        .getSharedPreferences("login_prefs", Context.MODE_PRIVATE)

    private val _loginState = mutableStateOf<LoginResponse?>(null)
    val loginState: State<LoginResponse?> = _loginState

    private val _error = mutableStateOf<String?>(null)
    val error: State<String?> = _error

    /** ▶ 수정: 화면(UI)에서 에러 메시지 강제 세팅할 때 사용 */
    fun postError(msg: String) {
        _error.value = msg
    }

    /** ▶ 수정: 로그인 버튼 클릭 시 이전 상태 초기화 */
    fun resetState() {
        _error.value = null
        _loginState.value = null
    }

    fun login(userId: String, userPw: String) {
        viewModelScope.launch {
            try {
                val resp = RetrofitClient.memberService.login(
                    LoginRequest(userId, userPw)
                )
                if (resp.isSuccessful) {
                    val body = resp.body()
                    // ▶ 수정: response body 혹은 token 누락 시 예외 처리
                    if (body?.token.isNullOrBlank()) {
                        _error.value = "서버에서 토큰을 받지 못했습니다."
                        return@launch
                    }
                    // ▶ 기존: 토큰·user_id 저장
                    prefs.edit()
                        .putString("auth_token", body!!.token)
                        .putString("user_id", body.userNum)
                        .apply()

                    _loginState.value = body
                } else {
                    _error.value = "HTTP ${resp.code()}"
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
}