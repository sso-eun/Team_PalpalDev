package com.example.dundun_hi.data

import com.google.gson.annotations.SerializedName

data class ProfileResponse(
    @SerializedName("user_num") val userNum: String,
    @SerializedName("user_id")  val userId: String,
    @SerializedName("name")     val name: String?
)