package com.example.dundun_hi.network

import com.example.dundun_hi.data.LoginRequest
import com.example.dundun_hi.data.LoginResponse
import com.example.dundun_hi.data.ProfileResponse
import com.example.dundun_hi.data.SignupRequest
import com.example.dundun_hi.data.SignupResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST


interface MemberService {
    // /member/login 엔드포인트
    @POST("member/login")
    suspend fun login(@Body req: LoginRequest): Response<LoginResponse>

    // ▶ 로그인 후 토큰을 이용해서 사용자 정보를 가져오는 API
    @GET("/member/profile")
    suspend fun getProfile(
        @Header("Authorization") bearerToken: String
    ): Response<ProfileResponse>

    //signup
    @POST("/member/signup")
    suspend fun signup(@Body req: SignupRequest): Response<SignupResponse>

}
