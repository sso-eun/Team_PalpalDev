package com.example.dundun_hi.data

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("message") val message: String,
    @SerializedName("user_num") val userNum: String,
    @SerializedName("token")    val token: String?
)

