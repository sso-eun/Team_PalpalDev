// app/src/main/java/com/example/dundun_hi/ui/main/MainViewModel.kt
package com.example.dundun_hi.ui.main

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dundun_hi.data.ProfileResponse
import com.example.dundun_hi.network.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application): AndroidViewModel(application) {

    private val prefs = application
        .getSharedPreferences("login_prefs", Context.MODE_PRIVATE)

    // 서버에서 받아온 프로필을 담는 StateFlow
    private val _profile = MutableStateFlow<ProfileResponse?>(null)
    val profile: StateFlow<ProfileResponse?> = _profile

    fun loadProfile() {
        viewModelScope.launch {
            val token = prefs.getString("auth_token", null) ?: return@launch
            val resp = RetrofitClient.memberService.getProfile("Bearer $token")
            if (resp.isSuccessful) {
                _profile.value = resp.body()
            } else {
                // 에러 로깅
                _profile.value = null
                // Log.d("MainViewModel", "getProfile failed: ${resp.code()}")
            }
        }
    }
}
