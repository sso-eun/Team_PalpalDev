package com.example.dundun_hi.ui.login

import android.app.Application
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun LoginScreen(
    // ▶ vm 기본 생성자 파라미터로만 남깁니다.
    vm: LoginViewModel = viewModel(
        factory = ViewModelProvider.AndroidViewModelFactory
            .getInstance(LocalContext.current.applicationContext as Application)
    ),
    // ▶ 로그인 성공 시 token 을 전달
    onLoginSuccess: (token: String) -> Unit
) {
    // 아이디 / 비밀번호 변수
    var userId by remember { mutableStateOf("") }
    var userPw by remember { mutableStateOf("") }

    // ViewModel 상태 구독
    val loginRes by vm.loginState      // State<LoginResponse?>
    val errorMsg by vm.error           // State<String?>

    // ▶ 로그인 성공 시, token 을 callback 으로 전달
    loginRes?.let { body ->
        LaunchedEffect(body) {
            val token = body.token
            if (!token.isNullOrBlank()) {
                onLoginSuccess(token)
            } else {
                vm.postError("서버에서 토큰을 받지 못했습니다.")  // ▶ 수정: 토큰 없을 때 에러 상태 처리
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text("든든하이", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("로그인", fontSize = 65.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(32.dp))

        Text("아이디", fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = userId,
            onValueChange = { userId = it },
            placeholder = { Text("아이디를 입력해주세요") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )
        Spacer(Modifier.height(24.dp))

        Text("비밀번호", fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = userPw,
            onValueChange = { userPw = it },
            placeholder = { Text("비밀번호를 입력해주세요") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )
        Spacer(Modifier.height(40.dp))

        Button(
            onClick = {
                vm.login(
                    userId.trim(),
                    userPw.trim()
                )
                vm.resetState()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1AB277))
        ) {
            Text("로그인하기", color = Color.White, fontSize = 30.sp)
        }

        // 에러 메시지 표시
        errorMsg?.let { msg ->
            Spacer(Modifier.height(16.dp))
            Text(
                text = "로그인 실패: $msg",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}
