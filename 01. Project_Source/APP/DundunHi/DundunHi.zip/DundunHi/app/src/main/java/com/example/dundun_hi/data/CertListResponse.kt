package com.example.dundun_hi.data

data class CertListResponse(
    val results: List<CertItem>,
    val totalResults: Int,
    val totalPages: String,
    val currentPage: Int,
    val limit: Int
)
