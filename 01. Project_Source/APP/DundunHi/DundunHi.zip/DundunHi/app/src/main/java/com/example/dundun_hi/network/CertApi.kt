package com.example.dundun_hi.network

import com.example.dundun_hi.data.CertListResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface CertApi {
    @GET("cert/list")
    suspend fun getCertList(
        @Query("page") page: Int,
        @Query("limit") limit: Int
    ): CertListResponse
}
