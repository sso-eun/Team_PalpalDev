package com.example.dundun_hi.ui.login

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dundun_hi.network.RetrofitClient
import kotlinx.coroutines.launch

@Composable
fun GuardianScreen(
    onGuardianFindIdClick: () -> Unit,
    onSubmit: (name: String, phone: String) -> Unit = { _, _ -> },
    onSignupClick: () -> Unit,
    onLoadingNavigate: () -> Unit = {}
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text("든든하이", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("보호자 로그인", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(32.dp))

        Text("이름", fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            placeholder = { Text("이름을 입력해주세요") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )
        Spacer(Modifier.height(24.dp))

        Text("전화번호", fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            placeholder = { Text("전화번호를 입력해주세요") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )
        Spacer(Modifier.height(40.dp))

        Button(
            onClick = { onSubmit(name, phone) },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1AB277))
        ) {
            Text("로그인", color = Color.White, fontSize = 18.sp)
        }

        Spacer(Modifier.height(40.dp))

        Text("처음이신가요?", color = Color.Gray, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))

        Text("회원가입하기",
            color = Color.Black,
            fontSize = 18.sp,
            modifier = Modifier
                .padding(top = 4.dp)
                .clickable {
                    scope.launch {
                        try {
                            val response = RetrofitClient.certApi.getCertList(1, 20)
                            val userNum = 11 // TODO: SharedPreferences로 교체 예정

                            val myCert = response.results
                                .filter { it.guardian_no == userNum }
                                .maxByOrNull { it.req_no }

                            if (myCert?.status == 0) {
                                onLoadingNavigate()
                            } else {
                                onSignupClick()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "서버 오류: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
        )

        Spacer(Modifier.height(20.dp))
        Text("가입한 이름을 까먹으셨나요?", color = Color.Gray, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))

        Text("이름 찾기",
            color = Color.Black,
            fontSize = 18.sp,
            modifier = Modifier
                .padding(top = 4.dp)
                .clickable { onGuardianFindIdClick() }
        )
    }
}