package com.example.dundun_hi.ui.signup

import android.R.attr.fontWeight
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.dundun_hi.network.RetrofitClient
import kotlinx.coroutines.delay
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue


@Composable
fun LoadingScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val userNum = 11 // ← 하드코딩 OK
    var isLoading by remember { mutableStateOf(true) } // ← 이 줄도 이 안에 있어야 함

    LaunchedEffect(Unit) {
        try {
            val response = RetrofitClient.certApi.getCertList(1, 20)
            val myCert = response.results
                .filter { it.guardian_no == userNum }
                .maxByOrNull { it.req_no }

            when (myCert?.status) {
                0 -> isLoading = true // 그대로 유지
                1 -> navController.navigate("SeniorHomeScreen")
                2 -> navController.navigate("RejectedScreen")
                else -> navController.navigate("CertRequestScreen")
            }
        } catch (e: Exception) {
            Toast.makeText(context, "서버 오류: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    if (isLoading) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "가족관계 확인 중",
                fontSize = 35.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "확인까지 1~3일의 시간이 소요됩니다.",
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1AB277) // 연한 청록색 느낌
            )
        }
    }
}

