package com.example.dundun_hi.data

data class CertItem(
    val req_no: Int,
    val guardian_no: Int,
    val status: Int
    // 필요한 경우 여기에 more fields 추가
)
